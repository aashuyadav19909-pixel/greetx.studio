GreetX Studio 3D Website
=========================
Open index.html in a modern browser.

For a production project, move the file into a Vite/React app and replace the placeholder portfolio artwork with your real assets/logo.

The 3D scene uses Three.js from a browser CDN. Internet access is required for the CDN and Google Fonts when opening this standalone file.

Contact form is intentionally demo-only; connect a real backend/email provider before using it for submissions.
